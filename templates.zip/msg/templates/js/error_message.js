function showError(message) {
    if (!message) return;

    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.innerHTML = `
        <span class="error-close" onclick="closeError(this)">✕</span>
        <div class="error-error">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="svg-icon error">
                <path stroke-linecap="round" stroke-linejoin="round"
                    d="M12 9v3.75m9-.75a9 9 0 1 1-18 0 
                    9 9 0 0 1 18 0Zm-9 3.75h.008v.008H12v-.008Z">
                </path>
            </svg>
        </div>
        <h4 id="error-text" style="">${message}</h4>
        <div class="progress-bar"></div>
    `;

    const errorContainer = document.getElementById('error-container') || document.createElement('div');
    if (!errorContainer.id) {
        errorContainer.id = 'error-container';
        document.body.appendChild(errorContainer);
    }
    errorContainer.appendChild(errorDiv);

    updateErrorPositions();
    errorDiv.classList.add('active');

    const progressBar = errorDiv.querySelector('.progress-bar');
    progressBar.style.animation = 'none';
    progressBar.offsetHeight;
    progressBar.style.animation = 'progress 3s linear forwards';

    setTimeout(() => {
        errorDiv.classList.remove('active');
        errorDiv.classList.add('closing');
        setTimeout(() => {
            errorDiv.remove();
            updateErrorPositions();
        }, 350);
    }, 3000);
}

function showSuccess(message) {
    if (!message) return;

    const successDiv = document.createElement('div');
    successDiv.className = 'error-message'; // тот же класс, чтобы анимация и стили работали одинаково
    successDiv.innerHTML = `
        <span class="error-close" onclick="closeError(this)">✕</span>
        <div class="error-success">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="svg-icon success">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" />
            </svg>
        </div>
        <h4 id="error-text" style="">${message}</h4>
        <div class="progress-bar"></div>
    `;

    const errorContainer = document.getElementById('error-container') || document.createElement('div');
    if (!errorContainer.id) {
        errorContainer.id = 'error-container';
        document.body.appendChild(errorContainer);
    }
    errorContainer.appendChild(successDiv);

    updateErrorPositions();
    successDiv.classList.add('active');

    const progressBar = successDiv.querySelector('.progress-bar');
    progressBar.style.animation = 'none';
    progressBar.offsetHeight;
    progressBar.style.animation = 'progress 3s linear forwards';

    setTimeout(() => {
        successDiv.classList.remove('active');
        successDiv.classList.add('closing');
        setTimeout(() => {
            successDiv.remove();
            updateErrorPositions();
        }, 350);
    }, 3000);
}

function closeError(element) {
    const errorDiv = element.parentElement;
    errorDiv.classList.remove('active');
    errorDiv.classList.add('closing');
    setTimeout(() => {
        errorDiv.remove();
        updateErrorPositions();
    }, 350);
}

function updateErrorPositions() {
    const errorContainer = document.getElementById('error-container');
    if (!errorContainer) return;
    const errorMessages = errorContainer.querySelectorAll('.error-message');
    let offset = 20;
    errorMessages.forEach((msg, index) => {
        msg.style.bottom = `${offset + index * 70}px`;
    });
}

document.addEventListener('DOMContentLoaded', function () {
    {% if error_message %}
        showError("{{ error_message|escapejs }}");
    {% endif %}
});

window.closeError = closeError;
function delay(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}
document.addEventListener('DOMContentLoaded', function () {
    // Проверить, есть ли сообщение для показа после перезагрузки
    const messageToDisplay = sessionStorage.getItem('successMessageAfterReload');
    if (messageToDisplay) {
        // Удалить сообщение из хранилища, чтобы оно не появилось снова при следующей перезагрузке
        sessionStorage.removeItem('successMessageAfterReload');
        // Показать сообщение
        showSuccess(messageToDisplay);
    }
});

